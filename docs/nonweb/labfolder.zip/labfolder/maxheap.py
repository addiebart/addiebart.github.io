# Name: Addison Bartelli
# KUID: 3107921
# Date Made: 04/17/2024
# Date Edited: 04/17/2024
# Purpose: A max heap data structure, used to implement a priority queue.

class MaxHeap:
    def __init__(self) -> None: # boilerplate constructor
        self._heap = []

    def add(self, item): # adds item to heap
        self._heap.append(item) # add to the internal list
        self._upheap(self.size() - 1) # upheap the added item

    def _upheap(self, index):
        #thingy is at bottom
        #swap up accordning to lt
        parent_index = self._parent_index(index) # get index of parent
        if self._heap[index] > self._heap[parent_index]: # is parent less than me
            parent_value = self._heap[parent_index] # assign parent value
            self._heap[parent_index] = self._heap[index] # swap positons of myself and parent
            self._heap[index] = parent_value # ^
            self._upheap(parent_index) # recurse on the parent, which is now me.

    def _downheap(self, index): # value is at the top, swap values with children according to lt
        left_index = self._left_child_index(index) # get index of left child
        right_index = self._right_child_index(index) # get index of right child
        try:
            left = self._heap[left_index] # set to value if index exists
        except:
            left = -2 # set to a value that will never trigger the conditionals
        try: # set right value in the same way we set left value
            right = self._heap[right_index]
        except:
            right = -3
        value = self._heap[index] # get value of index passed
        if value < right or value < left: # if value has a greater child
            if left < right: # if the right child is the max of the children
                self._heap[right_index] = value # swap the values at the indexes
                self._heap[index] = right # ^
                self._downheap(right_index) # downheap on the given child
            else: # left child, similar to if block
                self._heap[left_index] = value
                self._heap[index] = left
                self._downheap(left_index)
        # else: pass

    def _left_child_index(self, index): # returns the theoritical index of the left child of an entry at an index
        return 2*index+1
    
    def _right_child_index(self, index): # returns the theoritical index of the right child of an entry at an index
        return 2*index+2
    
    def get(self, index): # allows access to values
        return self._heap[index] # return value at index
    
    def _parent_index(self, index): # provides parent index given the index of a child
        if index == 0: # if argument is root, return itself
            return index 
        return (index-1)//2 # otherwise provide parent by definition
    
    def remove(self): # removes root, edits tree to be heap-compliant
        if self.size() < 1:
            pass # if the heap is empty, do nothing
        elif self.size() == 1: # if root is the only value
            self._heap.pop() # remove only value
        else: # size >= 2
            self._heap[0] = self._heap[-1] # put last item at root
            self._heap.pop() # deletes last value
            self._downheap(0) # downheap root

    def size(self): # public access to heap size
        return len(self._heap) # returns length of inner list

    def __lt__(self, other): # I don't think I need this, but it was easy to code in, forwards __lt__ from list
        return self._heap.__lt__(other)