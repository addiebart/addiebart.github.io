#Author: Addison Bartelli
#KUID: 3107921
#Date: 2/12/2024
#Lab: lab02
#Last modified: 2/16/2024
#Purpose: Defines queues

#python was not happy with name "queue.py"

from node import Node

class MyQueue:
    def __init__(self): #boilerplate constructor
        self._front: Node = None
        self._back: Node = None

    def enqueue(self, value): #put value at back of queue
        newBack = Node(value) #make new node
        if not self.isEmpty() : #if back exists
            self._back.next = newBack #put new back node after it
            self._back = newBack #have back point to new back node
        else: #if empty
            self._front = newBack #if of size one, the back will be the same as the front.
            self._back = newBack #set new back

    def dequeue(self): #remove and return front value
        if self.isEmpty(): #if queue is empty return nothing.
            return None
        if self._back is self._front: #see line below
            self._back = None #If queue is of size one such that the front and back are the same, back also needs to be set to None. edge case.
        oldFront = self._front #put front in temp
        if self._front != None: #prevent dne errors
            self._front = self._front.next #set second in line as front.
        return oldFront.value #return front

    def isEmpty(self): #returns true if queue is empty
        return self._front == None