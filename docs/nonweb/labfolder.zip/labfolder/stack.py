#Author: Addison Bartelli
#KUID: 3107921
#Date: 2/12/2024
#Lab: lab02
#Last modified: 2/16/2024
#Purpose: Defines stacks, a FILO data structure

from node import Node

class Stack:
    def __init__(self): #constructor
        self._top = None

    def pop(self): #return top item and remove it from stack
        temp = self._top #store top in temp
        if self._top != None: #if top node exists
            self._top = temp.next #set top to next in line
        else: #if top node dne
            return None #return nothing
        return temp.value #return value of old top, temp gets GC

    def peek(self): #return front value
        if self._top == None: #if top node doesnt exist
            return None #reveal nothing to user
        return self._top.value #otherwise, if a thing does exist, reveal the thing.
    
    def isEmpty(self): #returns True if stack is empty
        return self._top == None # ^ determined by top being None
    
    def push(self, value): #add item to top of stack
        temp = Node(value) #make new node with value
        temp.next = self._top #link the existing stack to the end of the new node
        self._top = temp #replaces top