#Author: Addison Bartelli
#KUID: 3107921
#Date: 2/12/2024
#Lab: lab02
#Last modified: 2/16/2024
#Purpose: Defines nodes

#Foundation for linked structures.
class Node:
    def __init__(self, value): #boilerplate constructor
        self.value = value
        self.next = None