#Author: Addison Bartelli
#KUID: 3107921
#Date: 2/22/2024
#Lab: lab03
#Last modified: 2/22/2024
#Purpose: linked list, list made with nodes


from node import Node

class LinkedList:
    def __init__(self) -> None: # simple constructor
        self._top: Node = None # ^
        self._length: int = 0 # ^
    
    def length(self) -> int: # boilerplate property access method
        return self._length # returns value
    
    # insert(self, index: int, entry: any) -> None
    # insert value into list at index
    # throws RuntimeError on invalid index
    def insert(self, index: int, value) -> None:
        if index < 0 or index > self._length: #check for valid index
            raise RuntimeError # raise error if invalid

        if index == 0: # there is no node before index 0 so it must be handled as an edge case
            nodeTrail: Node = self._top # grab trail
            self._top = Node(value) # make new front
            self._top.next = nodeTrail # add trail, can be null
        else: # index is not zero
            nodeBefore: Node = self._getNodeAtIndex(index - 1) # get node before index
            nodeTrail: Node = nodeBefore.next # node trail is node after
            nodeBefore.next = Node(value) # reassign node after
            nodeBefore.next.next = nodeTrail # reattach trail at end, can be null

        self._length += 1 # increment length

    # appends a value to the end of the list
    def append(self, value) -> None:
        self.insert(self._length, value)  # calls insert index after the last
        
    # optional utility function
    # returns the node at a given index
    def _getNodeAtIndex(self, index: int) -> Node:
        if index < 0 or index > self._length - 1: #check for valid index
            raise IndexError # raise error if invalid
        
        if self._length == 1: #edge case to avoid operating on null
            return self._top 
        
        iteration: int = 0 #iteration counter
        currentNode: Node = self._top  #after iteration, currentNode will be the node at index - 1.
        while iteration < index:
            currentNode = currentNode.next #look at next node
            iteration += 1 #increment iteration counter
        return currentNode # return the node

    # remove(self, index: int)
    # Removes the entry at the index
    # throws RuntimeError
    def remove(self, index: int) -> None:
        if index < 0 or index > self._length - 1: #check for valid index
            raise RuntimeError # raise error if invalid

        if index == 0: #edge case to prevent operating values that dont exist
            self._top = self._top.next #shift list down by 1
        else:
            nodeBefore: Node = self._getNodeAtIndex(index - 1) #get node before index
            nodeBefore.next = nodeBefore.next.next #shifts list down by 1, overwriting index.
        
        self._length -= 1 # decrement length

    # returns the value at an index
    # valid index is checked in _getNodeAtIndex()
    #returns Any
    def getEntry(self, index: int):
        return self._getNodeAtIndex(index).value

    # utility dev method
    # prints all entries on new lines
    def _printEntries(self) -> None:
        for i in range(self._length): # loop through nodes
            print(self.getEntry(i)) # print value

    # reassigns a value given an index
    # valid index is checked in _getNodeAtIndex()
    def setEntry(self, index: int, value) -> None:
        self._getNodeAtIndex(index).value = value #get node and set its value

    # empties the list
    def clear(self) -> None:
        self._top = None #set top to null