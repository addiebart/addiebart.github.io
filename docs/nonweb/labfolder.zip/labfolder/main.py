from time import process_time_ns
from os import system
from LinkedList import LinkedList
from maxheap import MaxHeap
from myQueue import MyQueue
from stack import Stack

def main():
    try: # try block to prevent posix permission snafus
        system("rm -rf ./out && mkdir ./out") # reset out files, this line is is VERY safe.
    except:
        pass
    ONE_HUNDRED_THOUSAND = 100000 # set const
    for i in range(ONE_HUNDRED_THOUSAND // 1000): # iterate as many times as we need
        scalar = i + 1 # account for counting from zero
        items_to_add = scalar * 1000
        pop_single_item_stack(items_to_add)
        pop_all_items_stack(items_to_add)
        enqueue(items_to_add)
        linked_list_get_zero(items_to_add)
        linked_list_get_last(items_to_add)
        linked_list_print_all_get_entry(items_to_add)
        add_to_max_heap(items_to_add)

def pop_single_item_stack(items_to_add):
    stack = Stack()
    for _ in range(items_to_add):
        stack.push(0)
    start = process_time_ns()
    stack.pop()
    end = process_time_ns()
    time = end - start
    system(f"echo '{time},' >> ./out/one.csv") # write to file
    
def pop_all_items_stack(items_to_add):
    stack = Stack()
    for _ in range(items_to_add):
        stack.push(0)
    start = process_time_ns()
    while not stack.isEmpty():
        stack.pop()
    end = process_time_ns()
    time = end - start
    system(f"echo '{time},' >> ./out/two.csv") # write to file

def enqueue(items_to_add):
    queue = MyQueue()
    for _ in range(items_to_add):
        queue.enqueue(0)
    start = process_time_ns()
    queue.enqueue(0)
    end = process_time_ns()
    time = end - start
    system(f"echo '{time},' >> ./out/three.csv") # write to file

def linked_list_get_zero(items_to_add):
    llist = LinkedList()
    for _ in range(items_to_add):
        llist.append(0)
    start = process_time_ns()
    llist.getEntry(0)
    end = process_time_ns()
    time = end - start
    system(f"echo '{time},' >> ./out/four.csv") # write to file

def linked_list_get_last(items_to_add):
    llist = LinkedList()
    for _ in range(items_to_add):
        llist.append(0)
    start = process_time_ns()
    llist.getEntry(llist.length() - 1)
    end = process_time_ns()
    time = end - start
    system(f"echo '{time},' >> ./out/five.csv") # write to file

def linked_list_print_all_get_entry(items_to_add):
    llist = LinkedList()
    for _ in range(items_to_add):
        llist.append(0)
    start = process_time_ns()
    llist._printEntries()
    end = process_time_ns()
    time = end - start
    system(f"echo '{time},' >> ./out/six.csv") # write to file

def add_to_max_heap(items_to_add):
    maxheap = MaxHeap()
    for _ in range(items_to_add):
        maxheap.add(0)
    start = process_time_ns()
    maxheap.add(0)
    end = process_time_ns()
    time = end - start
    system(f"echo '{time},' >> ./out/seven.csv") # write to file

main()